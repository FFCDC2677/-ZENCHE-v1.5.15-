# Nikon camera hardware acceptance checklist

Record the camera firmware, lens, USB cable and host OS before testing.

- [ ] Z7 (`04b0:0442`) is identified by its correct model name.
- [ ] Z6 (`04b0:0443`) is identified by its correct model name.
- [ ] Z50 (`04b0:0444`) is identified by its correct model name.
- [ ] D780 (`04b0:0446`) is identified by its correct model name.
- [ ] D6 (`04b0:0447`) is identified by its correct model name.
- [ ] Z5 (`04b0:0448`) is identified by its correct model name.
- [ ] Z7II (`04b0:044b`) is identified by its correct model name.
- [ ] Z6II (`04b0:044c`) is identified by its correct model name.
- [ ] Z fc (`04b0:044f`) is identified by its correct model name.
- [ ] Z9 (`04b0:0450`) is identified by its correct model name.
- [ ] Z8 (`04b0:0451`) is identified by its correct model name.
- [ ] Z30 (`04b0:0452`) is identified by its correct model name.
- [ ] Z f (`04b0:0453`) is identified by its correct model name.
- [ ] Z6III (`04b0:0454`) is identified by its correct model name.
- [ ] Z50II (`04b0:0455`) is identified by its correct model name.
- [ ] Z5II (`04b0:0456`) is identified by its correct model name.
- [ ] ZR (`04b0:0457`) is identified by its correct model name or descriptor fallback.
- [ ] Other Nikon USB models are rejected with their actual Product ID.
- [ ] **Canon EOS R6 Mark III（待设备）**：USB/PTP 被识别为「Canon EOS R6 Mark III」，
      名称正确、ISO 范围显示 100–102400；Sony/Canon VID 通配（0x054c / 0x04a9）
      不误匹配 Nikon 机型。注：Canon 深度控制（对焦/快门/LiveView 专属 opcode）为
      TBC 未实机验证项，入册仅覆盖识别/名称/ISO 范围/泛型 PTP 连接。
- [ ] **Canon EOS 录像（待设备，C2 1.5.8）**：Android/Harmony/Windows 在佳能
      （VID 0x04a9）上开始/停止录像经 EOS_SetDevicePropValueEx(0x9110) 写
      EVFRecordStatus(0xD1b8)（1=开始 0=停止）；机身出现「录像中」指示、再次
      停止后生成视频文件。实现按 libgphoto2 常量 + digiCamControl/qDslrDashboard
      社区方案，未经实机验证（TBC-awaiting-hardware），实机条目通过后移除该标注。
- [ ] **Canon EOS 实时取景（待设备，E2 1.5.9）**：Android/Harmony/Windows 在佳能
      （VID 0x04a9）上取景启停经 EVFMode(0xD1b1)/EVFOutputDevice(0xD1b0) 条件写
      （EVFOutputDevice 仅 (cur & ~1)==0 时写 2=PC），取帧走 EOS_GetViewFinderData
      (0x9153) 并解出内嵌 JPEG（EOS dataset type 1/9/11）；视频监看实时刷新、
      停止取景后机身回到 TFT 显示。实现对齐 libgphoto2 library.c/ptp.c，
      未经实机验证（TBC-awaiting-hardware），实机条目通过后移除该标注。
- [ ] **Canon EOS 取景态参数读写（待设备，E2 1.5.9）**：EVF/Movie 态下 ISO/
      光圈/快门经标准 GetDevicePropValue(0x1015) 读取、经 0x9110 写入（gphoto2
      对 EOS 属性读同样走标准 0x1015；0x9114 实为 SetRemoteMode 非属性读）；
      步进后机身数值变化且读回一致。
- [ ] **macOS Canon 实时取景（待设备，E2 1.5.9）**：gphoto2 厂商中立管道
      拉取佳能实时取景（未经实机验证）；本批不改 macOS 代码，仅挂条目。
- [ ] Android displays a USB permission prompt once and reconnects after relaunch.
- [ ] HarmonyOS displays the system USB permission prompt and reconnects after
      unplug/replug without retaining stale endpoints.
- [ ] Windows reports a clear WinUSB/libusb driver action when the PTP interface
      is owned by the system or another application.
- [ ] Live view starts, refreshes continuously and stops when disabled.
- [ ] One shutter press creates exactly one file in the local library.
- [ ] Captured JPEG opens at full resolution and has a valid EXIF timestamp.
- [ ] Shutter speed, aperture, ISO sensitivity and exposure compensation change on the body.
- [ ] P, S, A and M shooting modes change on the body.
- [ ] M mode with the Bulb shutter speed opens and closes after the app-selected duration.
- [ ] P locks shutter and aperture; A locks shutter; S locks aperture.
- [ ] M exposes shutter, aperture and ISO while locking exposure compensation.
- [ ] M (Bulb) exposes aperture, ISO sensitivity and app duration while locking
      the regular shutter-speed control and exposure compensation.
- [ ] The local stripe pattern appears only above the selected 70–100 IRE threshold.
- [ ] A valid 3D `.cube` LUT changes live view but not the captured JPEG bytes.
- [ ] Invalid, incomplete and 1D LUT files show an actionable import error.
- [ ] Auto, Standard, Neutral, Vivid, Monochrome, Portrait, Landscape and Flat
      Picture Controls either change on the body or report unsupported clearly.
- [ ] White balance, focus mode and shooting mode report unsupported values clearly.
- [ ] Monitor-page ISO sensitivity, preset white-balance and exposure controls
      update the camera body.
- [ ] Enabling local 2× supersampling changes preview resampling without changing
      the captured JPEG bytes.
- [ ] Nikon PTP live-view format is shown as camera-output JPEG and cannot be
      mistaken for the camera's video file type.
- [ ] Switching the 720p / 1080p monitor display size updates the local output label
      and keeps the live-view loop responsive.
- [ ] Disconnecting the cable disables the shutter without losing saved files.
- [ ] Reconnecting after sleep restores live view without restarting the host.
- [ ] A 50-frame session completes without a leaked USB handle or stalled queue.

## Wireless transfer

- [ ] Starting the wireless inbox shows the receiver IPv4 address,
      FTP port 2121, and HTTP/WebDAV port 8080.
- [ ] Camera FTP profile logs in with `nikonlink` / `nikonlink` and PASV enabled.
- [ ] HTTP PUT to `/upload/<filename>` with Basic Auth stores byte-identical data.
- [ ] HTTP POST accepts a filename from the path, `filename` query item, or
      `X-Filename` header and rejects a missing `Content-Length`.
- [ ] WebDAV `OPTIONS`, `PROPFIND`, `MKCOL`, and authenticated `PUT` complete
      with standards-compatible status codes.
- [ ] Missing or incorrect HTTP Basic Auth receives `401` without creating a file.
- [ ] Manual JPEG upload appears in the 帧澈 ZENCHE library without restarting.
- [ ] NEF and HEIF uploads keep their original filename and extension.
- [ ] Auto upload receives consecutive captures without overwriting an existing file.
- [ ] Stopping the wireless inbox rejects new FTP, HTTP, and WebDAV connections.
- [ ] Windows chooses a free PASV data port and streams large files to a temporary
      `.part` file before the final atomic move.
- [ ] HarmonyOS listens on PASV data port 2122 only while FTP is transferring,
      and closes ports 2121, 2122, and 8080 after leaving the page.

## Windows

- [ ] `ZENCHE.exe` starts on a clean Windows 11 x64 machine with the packaged
      `libusb-1.0.dll`.
- [ ] The x64 package rejects x86/ARM64 libusb DLLs with an actionable message.
- [ ] Only the Nikon Still Image/PTP interface is bound to WinUSB or libusbK.
- [ ] Keyboard focus, window resizing at 1024×640, and 200% display scaling keep
      all critical controls operable.

## HarmonyOS

- [ ] The signed HAP installs on an API 12+ USB Host phone, tablet, and 2-in-1.
- [ ] The app remains usable at 320, 375, 414, and 768 vp widths.
- [ ] A PTP payload larger than 200 KB is reassembled correctly from 192 KB
      `bulkTransfer` calls.
- [ ] Removing the USB device during live view exits the loop and leaves the local
      photo library intact.

## iOS / iPadOS monitor output

- [ ] 720p60, 1080p30, 1080p60 and 2160p30 choose the closest supported
      AVFoundation format and report the actual dimensions and frame rate.
- [ ] H.264, HEVC and automatic output-encoding preferences persist after relaunch.
- [ ] Enabling 2× input sampling priority requests a higher format where available
      and falls back to the closest device-supported format without stopping preview.

## Live 图（取景帧环形缓冲 + 快门切片配对）— E5 1.5.9（待设备，TBC-awaiting-hardware）

- [ ] **macOS live 图**：设置开「Live 图」（默认关）后本机/USB 快门，照片与
      `{base}_live.avi` 切片同 base 入库（切片约为快门时刻前最近 N 秒，默认 3s，
      1/3/5/10/15s 可选）；切片时长正确、AVI 可播放（Motion-JPEG，帧数≈fps×N）；
      照片 XMP `xmp:Label="live-photo"` + `dc:relation` 指向 AVI、AVI XMP 反向指向
      照片；双备份与 SHA-256 清单包含 AVI 与两侧 XMP；关闭开关或停止取景后快门
      不再生成切片（无孤儿 AVI）。
- [ ] **iOS live 图**：本机摄像头快门附带切片（AVFoundation 喂帧转 JPEG 入环）；
      Wi‑Fi PTP 相机快门**不**生成切片（原片在相机卡，避免孤儿 AVI）；配对 XMP
      与时长设置同 macOS 口径。
- [ ] **Windows live 图**：本机/USB 快门切片配对（`{base}_live.avi` 同 base 入库、
      XMP 双向配对）；Wi‑Fi PTP 快门不切片；时长设置生效；另验证
      **StepWifiShutterAsync 顺修**——Wi‑Fi 快门 ± 步进逐档变化（旧实现降序分母
      + FindIndex 恒命中首档 1/8000，修复后按 升序阶梯+firstAtLeast 正确定位）。
- [ ] **Android live 图**：本机/USB 快门切片配对；Wi‑Fi PTP 快门不切片；拍摄辅助
      面板「Live 图」开关 + 1/3/5/10/15s Spinner 生效（开关默认关、默认 3s）；
      取景停止后环形缓冲 disarm（复开取景重新 arm，无残留切片）。
- [ ] **Harmony live 图**：本机/USB 快门切片配对（`{base}_live.avi` + XMP 双向）；
      Wi‑Fi PTP 快门不切片；设置「Live 图」Toggle + 时长 Select（1/3/5/10/15s）
      持久化并在重启后保留；取景停/disarm、每帧惰性 arm 行为正确。

## 延时合成视频 — E6 1.5.9（待设备，TBC-awaiting-hardware）

- [ ] **macOS 延时合成**：文件库入口「合成延时视频」→ 预选最近 8 帧（可改选、
      按文件名排序合成）→ 帧率 24/25/30 → H.264 MP4（可选 ProRes 422 → .mov）
      产出；逐帧解码→aspect-fit 黑底画布→编码链正确，首帧尺寸即输出尺寸
      （上限源尺寸）；损坏帧跳过并计数、不整批失败；进度显示 + 可取消；
      产出走 CaptureWorkflow 会话目录 + reserveBaseName 命名 + finalize 全套
      （XMP sidecar/双备份/SHA-256 清单）。
- [ ] **iOS 延时合成**：入口与合成行为同 macOS（H.264 MP4 / 可选 ProRes .mov）；
      帧率与分辨率口径一致；取消/进度/损坏帧跳过行为正确。
- [ ] **Windows 延时合成**：MediaComposition 静态帧 clip 渲染 H.264 MP4；入口/
      帧率 24/25/30/损坏帧跳过/进度取消/会话入库同口径。
- [ ] **Android 延时合成**：MediaCodec+MediaMuxer 序列帧合成 H.264 MP4（YUV420
      I420 输入、显式 bitrate=clamp(w*h*fps*0.07, 1M, 20M)、I 帧间隔 1）；入口/
      帧率/跳过/进度取消/会话入库同口径。
- [ ] **Harmony 延时合成**：native C++ 编码链（libtimelapse.so：
      OH_VideoEncoder H.264 + OH_AVMuxer MP4，NV12 输入、AVC Profile Main、
      bitrate 公式与 Android 对齐）在真机上编码/mux 正常；入口面板「合成延时
      视频」帧率 24/25/30 生效；进度/取消/损坏帧跳过/会话入库正确；确认
      buffer 模式回调（onNeedInputBuffer/onNewOutputBuffer）与
      NotifyEndOfStream+EOS 输出在实机上的行为（API 21 移除 ArkTS 低级编解码
      API，本端为唯一 native 路径，与其他四端高级 API 方案不同，需实机回归）。

## 焦点包围合成 — E7 1.5.9（待设备，TBC-awaiting-hardware）

- [ ] **macOS 焦点合成**：文件库入口「焦点合成」→ 预选最近 8 帧（可改选、
      按文件名排序合成，至少 2 帧）→ 合成 JPEG 产出；逐帧解码→aspect-fit
      黑底画布→全局亮度归一（clamp(mean0/mean_i, 0.5, 2.0)）→ 3×3 拉普拉斯
      清晰度测度 → 逐像素取最清晰帧融合正确（前景/背景对焦区域清晰度符合
      预期）；损坏帧跳过并计数、不整批失败；进度显示 + 可取消；产出走
      CaptureWorkflow 会话目录 + reserveBaseName + finalize 全套（XMP sidecar
      写 focus-stack 标记 + 源帧数/双备份/SHA-256 清单）。
- [ ] **iOS 焦点合成**：入口与合成行为同 macOS；XMP focus-stack 标记一致；
      取消/进度/损坏帧跳过行为正确。
- [ ] **Windows 焦点合成**：WinRT BitmapDecoder/Encoder 解码编码链正确；
      入口/跳过/进度取消/会话入库同口径。
- [ ] **Android 焦点合成**：BitmapFactory 解码 + 同构算法（I420 无关，纯
      ARGB 融合）+ JPEG 92 质量输出；入口/跳过/进度取消/会话入库同口径。
- [ ] **Harmony 焦点合成**：纯 ArkTS 图像栈（image 解码 → 画布 → 融合 →
      createPixelMap + ImagePacker JPEG）；入口面板/跳过/进度取消/会话入库
      正确；XMP focus-stack 标记与源帧数写入正确。

## Android / Harmony PTP/IP 遥控 — E4 1.5.9（待设备，TBC-awaiting-hardware）

- [ ] **Android Wi‑Fi 遥控**：连接尼康/佳能 PTP/IP 相机后自动识别厂商
      （GetDeviceInfo 0x1001 + 名称启发式），尼康/佳能自动开实时取景并拉帧
      （约 10fps）；Wi‑Fi 控制卡「开启/停止实时取景」「开始/停止录制」可用；
      ISO/光圈/快门步进写入后读回一致；录像文件保存在相机卡内；断连/重连后
      取景与参数自动恢复（对齐 Windows E3 行为）。
- [ ] **Harmony Wi‑Fi 遥控**：连接后自动识别厂商并开实时取景；控制卡
      「实时取景/录制」按钮与 ISO/光圈/快门步进行可用；预览循环按源路由
      （USB > 本机 > Wi‑Fi）取帧；断连/重连恢复取景与参数；录像走机身
      （文件在相机卡内）。
- [ ] **PTP/IP data-out 相位**（Android/Harmony 新增）：SetDevicePropValue
      (0x1016) 与 Canon 0x9110 经 请求→StartData(9)→EndData(12)→响应 相位
      写入成功，机身数值变化（对齐 docs/PTPIP_PROTOCOL.md 与 E3 两端）。

## macOS / Windows PTP/IP 遥控 — E3 1.5.9（待设备，TBC-awaiting-hardware）

- [ ] **macOS Wi‑Fi 遥控**：连接尼康/佳能 PTP/IP 相机后，监看页与全屏取景显示
      Wi‑Fi 实时取景帧（CGImage，约 10fps）；录像钮对 Wi‑Fi 相机走机身录像
      （Nikon 0x920a/0x920b；Canon EVFRecordStatus，TBC）；参数步进卡经
      0x1015/0x1016 读写 ISO/光圈/快门后机身数值变化且读回一致；离开监看页
      停止拉帧（不白空转）。
- [ ] **Windows Wi‑Fi 遥控**：连接后自动识别厂商（GetDeviceInfo 0x1001 +
      名称启发式），尼康/佳能自动开实时取景并拉帧；控制卡「开启/停止实时取景」
      「开始/停止录制」可用；ISO/光圈/快门步进写入后读回一致；录像文件保存在
      相机卡内；断连/重连后取景与参数自动恢复。
- [ ] **PTP/IP data-out 相位**（Windows 新增）：SetDevicePropValue(0x1016) 与
      Canon 0x9110 经 请求→StartData(9)→EndData(12)→响应 相位写入成功，机身
      数值变化（对齐 iOS 实现与 docs/PTPIP_PROTOCOL.md）。

## iOS PTP/IP (Wi‑Fi 相机) — C3 1.5.8（待设备，TBC-awaiting-hardware）

- [ ] **实时取景**：连接尼康/佳能 Wi‑Fi 相机后自动开实时取景，视频监看页与
      iPad 监看页持续刷新 JPEG 帧（约 10fps，单帧失败 300ms 退避重试）；
      断开连接后停止。尼康走 0x9201/0x9202/0x9203；佳能按 C2 序列
      （0x9110 写 EVFMode/EVFOutputDevice，Busy 容忍）后取 0x9153
      GetViewFinderData。
- [ ] **录像启停**：Wi‑Fi 连接且厂商识别为尼康/佳能时录像钮可用；开始/停止走
      尼康 0x920a/0x920b 或佳能 EVFRecordStatus(0xD1b8)（1=开始 0=停止）；
      REC 指示与时间码随录像走动，文件保存在相机卡内。Sony/未知厂商不误报
      录像能力。
- [ ] **参数读写**：ISO（0x500f）/ 光圈（0x5007）/ 快门（0x500d）经
      GetDevicePropValue(0x1015)/SetDevicePropValue(0x1016) 读取与写入，
      Wi‑Fi 参数卡步进后机身数值变化且读回一致。
- [ ] 心跳保活、断连清理与自动重连在新取景/录像路径下不回退：断连先停录像/
      取景再关会话，重连成功后自动恢复取景与参数。

## Current build status

The 1.0.0 stable release passes compilation, signature/container validation,
native UI startup checks and package scans. Windows passes .NET compilation and
PE/ZIP package checks. HarmonyOS source, resources, and unsigned HAP compilation
pass, but signing, startup, and hardware checks are still pending. No supported
EXPEED 6 / 7 body was attached to the build machine, so this checklist remains
the release gate for every platform and camera.
