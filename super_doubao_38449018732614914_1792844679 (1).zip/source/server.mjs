import { createHash } from "node:crypto";
import { createReadStream, existsSync, statSync, readFileSync, readdirSync, mkdirSync, openSync, closeSync, writeSync, fsyncSync, renameSync } from "node:fs";
import { createServer as createHttpServer } from "node:http";
import { extname, isAbsolute, join, normalize, resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import crypto from "node:crypto";

const root = fileURLToPath(new URL(".", import.meta.url));
const defaultRepository = "Tauber01/ZENCHE";
const defaultReleaseApi = `https://api.github.com/repos/${defaultRepository}/releases/latest`;
const defaultPort = 4173;
const defaultCacheTtlMs = 5 * 60 * 1000;

const contentTypes = new Map([
  [".html", "text/html; charset=utf-8"],
  [".css", "text/css; charset=utf-8"],
  [".js", "text/javascript; charset=utf-8"],
  [".mjs", "text/javascript; charset=utf-8"],
  [".json", "application/json; charset=utf-8"],
  [".webmanifest", "application/manifest+json; charset=utf-8"],
  [".svg", "image/svg+xml"],
  [".png", "image/png"],
]);

const platformAliases = new Map([
  ["ios", "ios"],
  ["ipados", "ios"],
  ["iphone", "ios"],
  ["ipad", "ios"],
  ["android", "android"],
  ["harmony", "harmonyos"],
  ["harmonyos", "harmonyos"],
  ["mac", "macos"],
  ["macos", "macos"],
  ["osx", "macos"],
  ["windows", "windows"],
  ["win", "windows"],
]);

const architectureAliases = new Map([
  ["x64", "x64"],
  ["amd64", "x64"],
  ["x86_64", "x64"],
  ["x86-64", "x64"],
  ["arm64", "arm64"],
  ["aarch64", "arm64"],
  ["arm", "arm64"],
  ["x86", "x86"],
  ["i386", "x86"],
]);

const channelNames = new Set(["stable", "beta", "preview", "nightly"]);

export function normalizeVersion(value) {
  const match = String(value ?? "").trim().replace(/^v/i, "").match(/\d+(?:\.\d+){0,3}(?:[-+][0-9A-Za-z.-]+)?/);
  return match ? match[0] : "0.0.0";
}

export function compareVersions(left, right) {
  const parse = (value) => {
    const [core, pre = ""] = normalizeVersion(value).split("-");
    const numbers = core.split(".").map((part) => Number(part) || 0);
    while (numbers.length < 4) numbers.push(0);
    return { numbers, pre };
  };
  const a = parse(left);
  const b = parse(right);
  for (let index = 0; index < a.numbers.length; index += 1) {
    if (a.numbers[index] !== b.numbers[index]) return a.numbers[index] > b.numbers[index] ? 1 : -1;
  }
  if (!a.pre && b.pre) return 1;
  if (a.pre && !b.pre) return -1;
  if (a.pre === b.pre) return 0;
  return a.pre.localeCompare(b.pre, undefined, { numeric: true });
}

function normalizePlatform(value) {
  const key = String(value ?? "").trim().toLowerCase();
  return platformAliases.get(key) || key || "unknown";
}

function normalizeArchitecture(value) {
  const key = String(value ?? "").trim().toLowerCase();
  return architectureAliases.get(key) || key || "unknown";
}

function safeRegex(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/** Select the best full installer asset for a normalized platform/architecture. */
export function selectReleaseAsset(assets, platform, architecture) {
  const normalizedPlatform = normalizePlatform(platform);
  const normalizedArchitecture = normalizeArchitecture(architecture);
  const candidates = (Array.isArray(assets) ? assets : []).filter(
    (asset) => asset && typeof asset.name === "string" && typeof asset.browser_download_url === "string",
  );
  const platformPattern = {
    ios: /(?:^|[-_.])ios(?:[-_.]|$)/i,
    android: /android/i,
    harmonyos: /harmony(?:os)?/i,
    macos: /macos|darwin|osx/i,
    windows: /windows|win32/i,
  }[normalizedPlatform];
  if (!platformPattern) return null;
  const platformCandidates = candidates.filter((asset) => platformPattern.test(asset.name));
  if (!platformCandidates.length) return null;
  if (normalizedArchitecture !== "unknown") {
    const architecturePattern = new RegExp(`(?:^|[-_.])${safeRegex(normalizedArchitecture)}(?:[-_.]|$)`, "i");
    const exact = platformCandidates.find((asset) => architecturePattern.test(asset.name));
    if (exact) return exact;

    // Never hand an arm64/x64-specific package to another architecture. A
    // package without an architecture marker is safe to use as a fallback.
    const markedArchitecture = /(?:^|[-_.])(?:x64|amd64|x86_64|x86-64|arm64|aarch64|x86|i386)(?:[-_.]|$)/i;
    const generic = platformCandidates.find((asset) => !markedArchitecture.test(asset.name));
    if (!generic) return null;
  }
  // Prefer installers over archives and checksum sidecars.
  return platformCandidates
    .filter((asset) => !/\.sha256(?:\.txt)?$/i.test(asset.name))
    .sort((a, b) => {
      const score = (name) => (/setup|installer|\.dmg$|\.apk$|\.hap$|\.ipa$/i.test(name) ? 0 : 1);
      return score(a.name) - score(b.name) || a.name.localeCompare(b.name);
    })[0] || null;
}

function releaseAnnouncement(release, configured) {
  const body = typeof release.body === "string" ? release.body.trim() : "";
  const firstHeading = body.match(/^#{1,3}\s+(.+)$/m)?.[1]?.trim();
  const announcement = configured && typeof configured === "object" ? configured : {};
  return {
    version: normalizeVersion(announcement.version || release.tag_name),
    title: String(announcement.title || release.name || firstHeading || `帧澈 ZENCHE ${normalizeVersion(release.tag_name)}`),
    body: String(announcement.body ?? body),
    published_at: announcement.published_at || release.published_at || release.created_at || null,
  };
}

function parseConfiguredAnnouncement(value) {
  if (!value) return null;
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === "object" ? parsed : null;
  } catch {
    return null;
  }
}

function releaseUrlFor(repository, release) {
  if (typeof release.html_url === "string" && /^https:\/\//i.test(release.html_url)) return release.html_url;
  return `https://github.com/${repository}/releases`;
}

function assetUrlFor(asset, configuredBaseUrl) {
  if (!asset || typeof asset.browser_download_url !== "string") return null;
  const baseUrl = String(configuredBaseUrl || "").trim().replace(/\/+$/, "");
  if (!baseUrl) return asset.browser_download_url;
  try {
    return new URL(encodeURIComponent(asset.name), `${baseUrl}/`).toString();
  } catch {
    return asset.browser_download_url;
  }
}

function releaseApiFor(repository, channel, configured) {
  if (configured) return configured;
  if (channel === "stable") return `https://api.github.com/repos/${repository}/releases/latest`;
  return `https://api.github.com/repos/${repository}/releases?per_page=30`;
}

function selectChannelRelease(payload, channel) {
  if (!Array.isArray(payload)) return payload;
  if (channel === "stable") {
    return payload.find((release) => release && !release.draft && !release.prerelease) || payload.find((release) => release && !release.draft) || null;
  }
  return payload.find((release) => {
    if (!release || release.draft) return false;
    const prerelease = Boolean(release.prerelease);
    return channel === "nightly" ? prerelease : prerelease;
  }) || payload.find((release) => release && !release.draft) || null;
}

function normalizeQuery(query = {}) {
  const channelValue = String(query.channel || "stable").trim().toLowerCase();
  return {
    platform: normalizePlatform(query.platform),
    architecture: normalizeArchitecture(query.architecture || query.arch || query.architecture_name),
    channel: channelNames.has(channelValue) ? channelValue : "stable",
    currentVersion: query.current_version || query.currentVersion || query.version || "",
  };
}

export function createUpdateService(options = {}) {
  const fetchImpl = options.fetchImpl || globalThis.fetch;
  if (typeof fetchImpl !== "function") throw new Error("fetch is required for update service");
  const repository = options.repository || process.env.UPDATE_REPOSITORY || defaultRepository;
  const configuredApi = options.releaseApi || process.env.UPDATE_RELEASE_API_URL || "";
  const cacheTtlMs = Number(options.cacheTtlMs ?? process.env.UPDATE_CACHE_TTL_MS ?? defaultCacheTtlMs);
  const now = options.now || (() => Date.now());
  const configuredAnnouncement = options.announcement || parseConfiguredAnnouncement(process.env.UPDATE_ANNOUNCEMENT_JSON);
  const minimumVersion = options.minimumVersion ?? process.env.UPDATE_MINIMUM_SUPPORTED_VERSION ?? null;
  const assetBaseUrl = options.assetBaseUrl ?? process.env.UPDATE_ASSET_BASE_URL ?? "";
  const manifestPath = options.manifestPath ?? process.env.UPDATE_RELEASE_MANIFEST ?? "";
  // 清单模式：设置 UPDATE_RELEASE_MANIFEST 后 /api/update 完全走本地清单，零 GitHub 请求。
  const manifestMode = manifestPath.length > 0;
  const cache = new Map();
  const inFlight = new Map();
  let manifest = null; // 内存缓存清单（热加载时刷新）
  let manifestMtime = 0;
  let manifestError = null;

  // 读取并校验本地清单；文件缺失/JSON 损坏 → 记录错误（getUpdate 抛 503 不外泄详情）。
  function loadManifest() {
    try {
      const stat = statSync(manifestPath);
      if (stat.mtimeMs === manifestMtime && manifest !== null) {
        return manifest;
      }
      const raw = readFileSync(manifestPath, "utf8");
      const parsed = JSON.parse(raw);
      if (typeof parsed !== "object" || parsed === null
          || typeof parsed.version !== "string"
          || typeof parsed.assets !== "object" || parsed.assets === null) {
        throw new Error("invalid manifest shape");
      }
      manifest = parsed;
      manifestMtime = stat.mtimeMs;
      manifestError = null;
      return parsed;
    } catch (error) {
      manifestError = error;
      return null;
    }
  }

  async function fetchRelease(channel) {
    // 清单模式不发起任何 GitHub 请求。
    if (manifestMode) {
      return loadManifest();
    }
    const url = releaseApiFor(repository, channel, configuredApi);
    const response = await fetchImpl(url, {
      headers: {
        Accept: "application/vnd.github+json",
        "User-Agent": `ZENCHE-update-service/${normalizeVersion(process.env.npm_package_version || "1.5.0")}`,
      },
    });
    if (!response || !response.ok) throw new Error(`GitHub release request failed (${response?.status || "unknown"})`);
    const payload = await response.json();
    const release = selectChannelRelease(payload, channel);
    if (!release || typeof release.tag_name !== "string") throw new Error("GitHub returned no usable release");
    return release;
  }

  async function getUpdate(query = {}) {
    const normalized = normalizeQuery(query);
    // 清单模式：fail-closed——清单缺失/损坏 → 503 不外泄详情；
    // 缺 UPDATE_ASSET_BASE_URL → 503。
    if (manifestMode) {
      if (!assetBaseUrl) {
        const error = new Error("UPDATE_ASSET_BASE_URL is required in manifest mode");
        error.status = 503;
        error.hideDetail = true;
        throw error;
      }
      const release = loadManifest();
      if (!release) {
        const error = new Error(manifestError ? "manifest unavailable" : "manifest unavailable");
        error.status = 503;
        error.hideDetail = true;
        throw error;
      }
      const timestamp = now();
      const generatedAt = new Date(timestamp).toISOString();
      return buildResponse(release, normalized, generatedAt, false);
    }
    const key = normalized.channel;
    const timestamp = now();
    const previous = cache.get(key);
    if (previous && timestamp - previous.fetchedAt < cacheTtlMs) {
      return buildResponse(previous.release, normalized, previous.generatedAt, false);
    }
    try {
      let request = inFlight.get(normalized.channel);
      if (!request) {
        request = fetchRelease(normalized.channel).finally(() => inFlight.delete(normalized.channel));
        inFlight.set(normalized.channel, request);
      }
      const release = await request;
      const generatedAt = new Date(now()).toISOString();
      cache.set(key, { release, fetchedAt: now(), generatedAt });
      return buildResponse(release, normalized, generatedAt, false);
    } catch (error) {
      if (previous) return buildResponse(previous.release, normalized, previous.generatedAt, true);
      throw error;
    }
  }

  function manifestAssetFor(release, platform, architecture) {
    const assets = release.assets || {};
    // 匹配顺序：platform/arch → platform 兜底。
    const candidates = [
      `${platform}/${architecture}`,
      platform,
    ];
    for (const key of candidates) {
      const asset = assets[key];
      if (asset && typeof asset === "object" && asset.file) {
        return asset;
      }
    }
    return null;
  }

  function buildResponse(release, normalized, generatedAt, stale) {
    // 清单模式：release 直接带 version/body/published_at；assets 按 platform/arch 键匹配。
    const isManifest = manifestMode;
    const version = normalizeVersion(
      isManifest ? release.version : release.tag_name
    );
    const selectedAsset = isManifest
      ? manifestAssetFor(release, normalized.platform, normalized.architecture)
      : selectReleaseAsset(release.assets, normalized.platform, normalized.architecture);
    // 清单模式：url = UPDATE_ASSET_BASE_URL + '/' + file；无匹配时 url=null（前端自行处理无包情形）。
    let url;
    let sha256 = null;
    if (isManifest) {
      url = selectedAsset ? `${assetBaseUrl.replace(/\/+$/, "")}/${selectedAsset.file}` : null;
      sha256 = selectedAsset?.sha256
        ? String(selectedAsset.sha256).replace(/^sha256:/i, "").toLowerCase()
        : null;
    } else {
      url = assetUrlFor(selectedAsset, assetBaseUrl) || releaseUrlFor(repository, release);
      const checksumAsset = selectedAsset && Array.isArray(release.assets)
        ? release.assets.find((asset) => new RegExp(`^${safeRegex(selectedAsset.name)}\\.sha256(?:\\.txt)?$`, "i").test(asset?.name || ""))
        : null;
      const sha256Source = selectedAsset?.sha256 || selectedAsset?.digest || checksumAsset?.sha256 || checksumAsset?.digest;
      sha256 = typeof sha256Source === "string"
        ? sha256Source.replace(/^sha256:/i, "").toLowerCase()
        : null;
    }
    // 清单模式：releaseAnnouncement 读 GitHub 形状的 tag_name/name，
    // 这里把清单的 version/title 映射进去，避免 announcement 静默退回 0.0.0。
    const announcement = releaseAnnouncement(
      isManifest ? { ...release, tag_name: release.version, name: release.title } : release,
      configuredAnnouncement,
    );
    // 清单的 minimum_supported_version 优先（强制升级闸门），env/options 兜底。
    const effectiveMinimumVersion = isManifest
      && typeof release.minimum_supported_version === "string"
      && release.minimum_supported_version.trim()
      ? release.minimum_supported_version
      : minimumVersion;
    const updateAvailable = normalized.currentVersion ? compareVersions(version, normalized.currentVersion) > 0 : true;
    const releaseUrl = isManifest
      ? (release.release_url || "")
      : releaseUrlFor(repository, release);
    const response = {
      schema_version: 1,
      product: "ZENCHE",
      channel: normalized.channel,
      platform: normalized.platform,
      architecture: normalized.architecture,
      version,
      url,
      sha256,
      release_url: releaseUrl,
      update_type: isManifest ? "full" : (release.prerelease ? "preview" : "full"),
      announcement,
      minimum_supported_version: effectiveMinimumVersion ? normalizeVersion(effectiveMinimumVersion) : null,
      generated_at: generatedAt,
      update_available: updateAvailable,
      stale,
      // Compatibility aliases for native clients and older integrations.
      downloadUrl: url,
      releaseUrl: releaseUrl,
      updateAvailable,
      minimumVersion: effectiveMinimumVersion ? normalizeVersion(effectiveMinimumVersion) : null,
      asset: selectedAsset ? { name: selectedAsset.file || selectedAsset.name, size: selectedAsset.size ?? null } : null,
    };
    return response;
  }

  return { getUpdate, clearCache: () => cache.clear(), get cache() { return cache; } };
}

function setSecurityHeaders(response, origin) {
  response.setHeader("Permissions-Policy", "camera=(self), microphone=(), geolocation=()");
  response.setHeader("Referrer-Policy", "no-referrer");
  response.setHeader("X-Content-Type-Options", "nosniff");
  response.setHeader("X-Frame-Options", "DENY");
  response.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' blob: data:; media-src 'self' blob:; connect-src 'self'");
  response.setHeader("Access-Control-Allow-Origin", origin || "*");
  response.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
  response.setHeader("Access-Control-Allow-Headers", "Accept, Content-Type, User-Agent");
  response.setHeader("Vary", "Origin");
}

function json(response, status, value, requestMethod = "GET") {
  const body = JSON.stringify(value);
  response.statusCode = status;
  response.setHeader("Content-Type", "application/json; charset=utf-8");
  response.setHeader("Cache-Control", status === 200 ? "public, max-age=60, stale-while-revalidate=300" : "no-store");
  response.setHeader("ETag", `\"${createHash("sha256").update(body).digest("hex").slice(0, 24)}\"`);
  if (requestMethod !== "HEAD") response.end(body);
  else response.end();
}

// L1: anonymous usage store. 每次更新检查（客户端带 installId 时）追加一条
// {fingerprint, platform, version, ts} 到 data/usage-YYYY-MM-DD.json（按天分片）。
// 写入走与 ai-server 一致的 tmp→fsync→rename 耐久路径；测试注入内存实现。
export function createUsageStore({ dataDir, fs = null }) {
  const useMemory = fs !== null; // 测试注入内存模式；默认写盘
  const F = fs || {
    mkdirSync, existsSync, readFileSync, readdirSync,
    openSync, closeSync, writeSync, fsyncSync, renameSync,
  };
  const dayKey = (ts) => {
    const d = new Date(ts);
    const p = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  };
  const fileFor = (ts) => join(dataDir, `usage-${dayKey(ts)}.json`);
  const entries = []; // 内存模式（测试注入）时所有记录都进这里

  function persistDay(ts, records) {
    F.mkdirSync(dataDir, { recursive: true });
    const file = fileFor(ts);
    const tmp = `${file}.tmp`;
    const fd = F.openSync(tmp, "w", 0o600);
    try {
      F.writeSync(fd, JSON.stringify(records, null, 2));
      F.fsyncSync(fd);
    } finally {
      F.closeSync(fd);
    }
    F.renameSync(tmp, file);
  }

  function loadDay(ts) {
    const file = fileFor(ts);
    if (!F.existsSync(file)) return [];
    try {
      const parsed = JSON.parse(F.readFileSync(file, "utf8"));
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return []; // 损坏的当日文件按空处理，不阻断更新检查
    }
  }

  function allRecords(nowTs) {
    if (useMemory) return entries.slice();
    const day = 24 * 60 * 60 * 1000;
    const records = [];
    let files = [];
    try {
      files = F.readdirSync(dataDir).filter((f) => /^usage-\d{4}-\d{2}-\d{2}\.json$/.test(f));
    } catch { /* dataDir 未创建 -> 空 */ }
    for (const file of files) {
      const filePath = join(dataDir, file);
      try {
        if (!F.existsSync(filePath)) continue;
        const parsed = JSON.parse(F.readFileSync(filePath, "utf8"));
        if (Array.isArray(parsed)) records.push(...parsed);
      } catch { /* 单个损坏文件跳过 */ }
    }
    return records;
  }

  return {
    // 返回是否记录成功；任何 IO 错误静默返回 false（不阻断更新响应）。
    record(platform, version, installId, ts = Date.now()) {
      if (!installId) return false;
      const fingerprint = crypto.createHash("sha256")
        .update(String(installId), "utf8").digest("hex").slice(0, 12);
      const record = { fingerprint, platform, version, ts };
      try {
        if (useMemory) {
          entries.push(record);
          return true;
        }
        const today = loadDay(ts);
        today.push(record);
        persistDay(ts, today);
        return true;
      } catch {
        return false;
      }
    },
    // DAU/WAU/累计安装 + 平台/版本拆分（按指纹去重，取每个指纹最新记录）。
    stats(nowTs = Date.now()) {
      const day = 24 * 60 * 60 * 1000;
      const all = new Map(); // fingerprint -> latest record
      for (const item of allRecords(nowTs)) {
        if (!item || !item.fingerprint) continue;
        const ts = Number(item.ts) || 0;
        const prev = all.get(item.fingerprint);
        if (!prev || ts > prev.ts) all.set(item.fingerprint, item);
      }
      const byPlatform = {};
      const byVersion = {};
      let dau = 0;
      let wau = 0;
      for (const item of all.values()) {
        const ts = Number(item.ts) || 0;
        if (nowTs - ts <= day) dau += 1;
        if (nowTs - ts <= 7 * day) wau += 1;
        const p = item.platform || "unknown";
        byPlatform[p] = (byPlatform[p] || 0) + 1;
        const v = item.version || "unknown";
        byVersion[v] = (byVersion[v] || 0) + 1;
      }
      return {
        totalInstallations: all.size,
        dau,
        wau,
        byPlatform,
        byVersion,
        generated_at: new Date(nowTs).toISOString(),
      };
    },
    _entries: entries,
  };
}

export function createApp(options = {}) {
  const updateService = options.updateService || createUpdateService(options);
  const corsOrigin = options.corsOrigin || process.env.UPDATE_CORS_ORIGIN || "*";
  // L1: anonymous usage telemetry. installId 只存 sha256 前 12 位指纹。
  // usageStore 可注入（测试用内存实现）；默认落到 data/usage-YYYY-MM-DD.json。
  const usageStore = options.usageStore || createUsageStore({
    dataDir: options.dataDir || process.env.UPDATE_DATA_DIR || join(root, "data"),
  });
  const adminSecret = options.adminSecret || process.env.UPDATE_ADMIN_SECRET || "";
  const statsSecret = options.statsSecret || adminSecret; // /api/stats 鉴权：回环优先，允许显式 Bearer
  const now = options.now || (() => Date.now());
  return createHttpServer(async (request, response) => {
    setSecurityHeaders(response, corsOrigin);
    let requestUrl;
    try {
      requestUrl = new URL(request.url || "/", `http://${request.headers.host || "localhost"}`);
    } catch {
      json(response, 400, { error: "invalid_url" }, request.method);
      return;
    }
    const pathname = requestUrl.pathname;
    if (request.method === "OPTIONS") {
      response.statusCode = 204;
      response.end();
      return;
    }
    if (pathname === "/healthz") {
      json(response, 200, { status: "ok", service: "zenche-update", generated_at: new Date().toISOString() }, request.method);
      return;
    }
    if (pathname === "/api/update" || pathname === "/api/updates") {
      if (request.method !== "GET" && request.method !== "HEAD") {
        json(response, 405, { error: "method_not_allowed" }, request.method);
        return;
      }
      // L1: anonymous usage heartbeat. Optional installId 只存 12 位指纹；
      // 记录失败绝不影响更新响应（静默）。
      try {
        const query = Object.fromEntries(requestUrl.searchParams.entries());
        const platform = normalizePlatform(query.platform || "unknown");
        const installId = String(query.installId || "").trim().slice(0, 128);
        if (installId) {
          usageStore.record(platform, query.current_version || query.version || "unknown", installId, now());
        }
        const result = await updateService.getUpdate(query);
        const etag = `\"${createHash("sha256").update(JSON.stringify(result)).digest("hex").slice(0, 24)}\"`;
        response.setHeader("ETag", etag);
        if (request.headers["if-none-match"] === etag) {
          response.statusCode = 304;
          response.end();
          return;
        }
        json(response, 200, result, request.method);
      } catch (error) {
        json(response, 503, { error: "update_unavailable", message: "Update metadata is temporarily unavailable" }, request.method);
      }
      return;
    }
    if (pathname === "/api/stats") {
      if (request.method !== "GET" && request.method !== "HEAD") {
        json(response, 405, { error: "method_not_allowed" }, request.method);
        return;
      }
      // 回环直连或显式 Bearer 常数时间比较；其余 403/401。
      const remote = request.socket.remoteAddress || "";
      const loopback = remote === "127.0.0.1" || remote === "::1" || remote === "::ffff:127.0.0.1";
      const header = request.headers.authorization;
      const token = typeof header === "string" ? /^Bearer\s+(\S+)$/i.exec(header)?.[1] : null;
      if (statsSecret && token) {
        const ha = createHash("sha256").update(token, "utf8").digest();
        const hb = createHash("sha256").update(statsSecret, "utf8").digest();
        if (crypto.timingSafeEqual(ha, hb)) {
          json(response, 200, usageStore.stats(now()), request.method);
          return;
        }
      }
      if (loopback && statsSecret) {
        if (!token) {
          json(response, 401, { error: "unauthorized" }, request.method);
          return;
        }
        const ha = createHash("sha256").update(token, "utf8").digest();
        const hb = createHash("sha256").update(statsSecret, "utf8").digest();
        if (crypto.timingSafeEqual(ha, hb)) {
          json(response, 200, usageStore.stats(now()), request.method);
          return;
        }
        json(response, 401, { error: "unauthorized" }, request.method);
        return;
      }
      json(response, loopback ? 401 : 403, { error: "forbidden" }, request.method);
      return;
    }
    if (request.method !== "GET" && request.method !== "HEAD") {
      response.statusCode = 405;
      response.setHeader("Allow", "GET, HEAD, OPTIONS");
      response.end("Method not allowed");
      return;
    }
    let pathnameDecoded;
    try {
      pathnameDecoded = decodeURIComponent(pathname);
    } catch {
      response.statusCode = 400;
      response.end("Bad request");
      return;
    }
    // E1 安全修复（AI审查 门禁阻塞项）：usage 数据默认落 root/data，
    // 静态服务此前对 /data/ 下任意文件无鉴权 GET 放行，架空 /api/stats 门禁。
    // 显式拒绝 /data/ 前缀（403，大小写不敏感——APFS 等大小写不敏感 FS 上
    // /DATA/ 变体可绕过，比较前统一小写）；不影响 /api/update 与正常静态文件。
    const pathnameLower = pathnameDecoded.toLowerCase();
    if (pathnameLower === "/data" || pathnameLower.startsWith("/data/")) {
      response.statusCode = 403;
      response.setHeader("Content-Type", "text/plain; charset=utf-8");
      response.end("Forbidden");
      return;
    }
    const safePath = normalize(pathnameDecoded).replace(/^(\.\.[/\\])+/, "");
    let filePath = join(root, safePath === "/" ? "index.html" : safePath);
    if (!filePath.startsWith(root) || !existsSync(filePath)) {
      response.statusCode = 404;
      response.setHeader("Content-Type", "text/plain; charset=utf-8");
      response.end("Not found");
      return;
    }
    if (statSync(filePath).isDirectory()) filePath = join(filePath, "index.html");
    response.setHeader("Content-Type", contentTypes.get(extname(filePath)) || "application/octet-stream");
    response.setHeader("Cache-Control", "no-cache");
    if (request.method === "HEAD") {
      response.statusCode = 200;
      response.end();
      return;
    }
    createReadStream(filePath)
      .on("error", () => {
        if (!response.headersSent) response.writeHead(500);
        response.end("Server error");
      })
      .pipe(response);
  });
}

export function startServer(options = {}) {
  const host = options.host || process.env.HOST || "127.0.0.1";
  const port = Number(options.port ?? process.env.PORT ?? defaultPort);
  const server = createApp(options);
  server.listen(port, host, () => {
    const displayHost = host === "0.0.0.0" ? "localhost" : host;
    console.log(`帧澈 ZENCHE is running at http://${displayHost}:${port}`);
  });
  return server;
}

const invokedPath = process.argv[1] ? resolve(process.argv[1]) : "";
if (invokedPath && isAbsolute(invokedPath) && invokedPath === resolve(fileURLToPath(import.meta.url))) {
  startServer();
}
